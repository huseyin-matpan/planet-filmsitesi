<?php
$page_baslik = 'Filmler';
include "baglanti.php";

$kategori_id = $_GET['id'];
$kategori_ad = $_GET['kategori'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Planet</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/global.css" rel="stylesheet">
	<link href="css/blog.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani&display=swap" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js"></script>

</head>

<body>

	<section id="top">
		<div class="container">
			<div class="row top_1">
				<div class="col-md-3">
					<div class="top_1l pt-1">
						<h3 class="mb-0"><a class="text-white" href="../index.php"><i class="fa fa-video-camera col_red me-1"></i> Planet</a></h3>
					</div>
				</div>
				<div class="col-md-5">
					<div class="top_1m">
						<form action="./sorgusonuc.php" method="get">
							<div class="input-group">
								<input type="text" class="form-control bg-black" placeholder="Film Ara" name="sorgu">
								<span class="input-group-btn">
									<button class="btn btn text-white bg_red rounded-0 border-0" type="submit">
										Araştır</button>
								</span>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-4">
					<div class="top_1r text-end">
						<ul class="social-network social-circle mb-0">
							<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-instagram"></i></a></li>
							<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
							<li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="header">
		<nav class="navbar navbar-expand-md navbar-light" id="navbar_sticky">
			<div class="container">
				<a class="navbar-brand text-white fw-bold" href="index.html"><i class="fa fa-video-camera col_red me-1"></i> Planet</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav mb-0">
						<?php
						$sorgu = "SELECT * FROM menuler";
						$sonuc = mysqli_query($conn, $sorgu);
						while ($menu = $sonuc->fetch_assoc()) : ?>
							<li class="nav-item">
								<a class="nav-link <?php if ($menu["menu_baslik"] == "$page_baslik") : echo "active";
													endif ?> " aria-current="page" href="
                                    <?php
									if ($menu["menu_baslik"] == "Anasayfa") {
										echo "index.php";
									} elseif ($menu["menu_baslik"] == "İletişim") {
										echo "iletişim.php";
									} else {
										echo trim(strtolower($menu["menu_baslik"])) . '.php';
									}
									?>"><?php echo $menu["menu_baslik"]
										?>
								</a>
							</li>
						<?php endwhile ?>
					</ul>
				</div>
			</div>
		</nav>
	</section>

	<section id="center" class="center_o pt-2 pb-2">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Film Detay</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Film Detay</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="blog" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="row blog_1">
				<div class="col-md-8">
					<div class="blog_1l">
						<div class="blog_1l1">
							<div class="popular_2i1lm position-relative clearfix">
								<div class="popular_2i1lm1 clearfix">
									<div class="grid">
										<figure class="effect-jazz mb-0">
											<?php
											$sorgu = "SELECT * FROM {$kategori_ad} WHERE id={$kategori_id}";
											$sonuc = mysqli_query($conn, $sorgu);
											if ($sonuc->num_rows > 0) {
												while ($film = $sonuc->fetch_assoc()) {
													echo $film['youtubeiafarme'];
												}
											} else {
												echo "<h1>Görüntü Yüklenemedi</h1> ";
											}
											?>

											<!-- <iframe height="560" class="w-100" src="https://www.youtube.com/embed/1_mv8ltHwb8?si=U5h-oyIss3_xd3Ls" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> -->

										</figure>
									</div>
								</div>

							</div>
							<div class="blog_1l1i mt-3">
								<h5><i class="fa fa-folder-open col_red me-1"></i> Film Detayları</h5>
								<?php
								$sorgu = "SELECT * FROM {$kategori_ad} WHERE id={$kategori_id}";
								$sonuc = mysqli_query($conn, $sorgu);
								while ($film = $sonuc->fetch_assoc()) :
								?>
									<h2 class="mt-3"><a class="col_red" href="#"><?php echo $film['baslik'] ?></a></h2>
									<h6 class="fw-normal mt-3 col_light">
										<span><i class="fa fa-clock-o me-1 align-middle col_red"></i>07.05.2024</span>
										<span class="ms-3"><i class="fa fa-user me-1 align-middle col_red"></i> Admin</span>
										<span class="ms-3"><i class="fa fa-comment me-1 align-middle col_red"></i> Yorumlar</span>
									</h6>
									<p class="mt-3"><?php echo $film['açıklama'] ?></p>
							</div>
						</div>
					<?php endwhile; ?>
					</div>
				</div>
				<div class="col-md-4">
					<div class="blog_1r">
						<div class="blog_1r1 p-4">
							<h4><span class="col_red">Menuler</span></h4>
							<hr class="line mb-4">
							<?php
							$sorgu = "SELECT * FROM `menuler`";
							$sonuc = mysqli_query($conn, $sorgu);
							while ($menu = $sonuc->fetch_assoc()) :
							?>
								<h6><a href="<?php
												if ($menu["menu_baslik"] == "Anasayfa") {
													echo "index.php";
												} elseif ($menu["menu_baslik"] == "İletişim") {
													echo "iletişim.php";
												} else {
													echo trim(strtolower($menu["menu_baslik"])) . '.php';
												}
												?>"><i class="fa fa-chevron-right me-1 col_red font_12"></i> <?php echo $menu['menu_baslik'] ?> <span class="pull-right"></span></a></h6>
								<hr>
							<?php endwhile; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<?php
	include "./views/_soneklenenler.php";
	include "./views/_footer.php";
	?>

	<script>
		window.onscroll = function() {
			myFunction()
		};

		var navbar_sticky = document.getElementById("navbar_sticky");
		var sticky = navbar_sticky.offsetTop;
		var navbar_height = document.querySelector('.navbar').offsetHeight;

		function myFunction() {
			if (window.pageYOffset >= sticky + navbar_height) {
				navbar_sticky.classList.add("sticky")
				document.body.style.paddingTop = navbar_height + 'px';
			} else {
				navbar_sticky.classList.remove("sticky");
				document.body.style.paddingTop = '0'
			}
		}
	</script>

</body>

</html>