<?php
$page_baslik = 'İletişim';
include "baglanti.php";
$sorgu = "SELECT * FROM `menuler`";
$sonuc = mysqli_query($conn, $sorgu);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Planet</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/global.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani&display=swap" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js"></script>

</head>

<body>

<section id="top">
    <div class="container">
      <div class="row top_1">
        <div class="col-md-3">
          <div class="top_1l pt-1">
            <h3 class="mb-0"><a class="text-white" href="./index.php"><i class="fa fa-video-camera col_red me-1"></i> Planet</a></h3>
          </div>
        </div>
        <div class="col-md-5">
          <div class="top_1m">
            <form action="./sorgusonuc.php" method="get">
            <div class="input-group">
              <input type="text" class="form-control bg-black" placeholder="Film Ara" name="sorgu">
              <span class="input-group-btn">
                <button class="btn btn text-white bg_red rounded-0 border-0" type="submit">
                  Araştır</button>
                </span>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-4">
          <div class="top_1r text-end">
            <ul class="social-network social-circle mb-0">
              <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-instagram"></i></a></li>
              <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
              <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="header">
    <nav class="navbar navbar-expand-md navbar-light" id="navbar_sticky">
      <div class="container">
        <a class="navbar-brand text-white fw-bold" href="index.html"><i class="fa fa-video-camera col_red me-1"></i> Planet</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mb-0">
            <?php while ($menu = $sonuc->fetch_assoc()) : ?>
              <li class="nav-item">
                <a class="nav-link <?php if ($menu["menu_baslik"] == "$page_baslik") : echo "active";
                                    endif ?> " aria-current="page" 
                                    href="
                                    <?php 
                                  if ($menu["menu_baslik"] == "Anasayfa") 
                                  {
                                    echo "index.php";
                                  } elseif($menu["menu_baslik"] == "İletişim") {
                                    echo "iletişim.php";
                                  }else{
                                    echo trim(strtolower($menu["menu_baslik"])) . '.php';
                                  } 
                                  ?>"><?php echo $menu["menu_baslik"] 
                                  ?>
                                  </a>
              </li>
            <?php endwhile ?>
          </ul>
        </div>
      </div>
    </nav>
  </section>
	<section id="center" class="center_o pt-2 pb-2">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">İletişim</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="./index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> İletişim</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="contact" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="row contact_1 bg_dark  pt-5 pb-5">
				<div class="col-md-3">
					<div class="contact_1i row">
						<div class="col-md-2 col-2">
							<div class="contact_1il">
								<span class="col_red fs-3"><i class="fa fa-map-marker"></i></span>
							</div>
						</div>
						<div class="col-md-10 col-10">
							<div class="contact_1ir">
								<h5 class="col_red">Şirket Addresi</h5>
								<p class="mb-0">İstanbul / Turkiye</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="contact_1i row">
						<div class="col-md-2 col-2">
							<div class="contact_1il">
								<span class="col_red fs-3"><i class="fa fa-clock-o"></i></span>
							</div>
						</div>
						<div class="col-md-10 col-10">
							<div class="contact_1ir">
								<h5 class="col_red">Çalışma Saatleri</h5>
								<p class="mb-0">Pazartesi - Cuma - 11.00 - 18.00</p>
								<p class="mb-0">Hafta Sonları - Kapalı</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="contact_1i row">
						<div class="col-md-2 col-2">
							<div class="contact_1il">
								<span class="col_red fs-3"><i class="fa fa-envelope"></i></span>
							</div>
						</div>
						<div class="col-md-10 col-10">
							<div class="contact_1ir">
								<h5 class="col_red">E-mail Adresleri</h5>
								<p class="mb-0">info@filmizle.com</p>
								<p class="mb-0">info@inovasyonsoftware.com</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="contact_1i row">
						<div class="col-md-2 col-2">
							<div class="contact_1il">
								<span class="col_red fs-3"><i class="fa fa-phone"></i></span>
							</div>
						</div>
						<div class="col-md-10 col-10">
							<div class="contact_1ir">
								<h5 class="col_red">Phone Numbers</h5>
								<p class="mb-0">-</p>
								<p class="mb-0">-</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row contact_2 mt-4">
				<div class="col-md-3">
					<div class="contact_2r">
						<h5 class="mb-3">İzmir Ofis</h5>
						<p><i class="fa fa-car col_red me-1"></i>İzmir / Turkiye</p>
						<p><i class="fa fa-phone col_red me-1"></i>-</p>
						<p><i class="fa fa-globe col_red me-1"></i> <a href="#">info@filmizle.com</a></p>
						<p><i class="fa fa-envelope col_red me-1"></i> <a href="#">info@filmizle.com</a></p>
						<h5 class="mb-3 mt-4">İzmir Çalışma Saatleri</h5>
						<p>Destek Merkezimi 7/24 Hizmet Vermektedir</p>
						<!-- <p>Monday – Friday : <span class="fw-bold text-white">9am to 7pm</span></p>
						<p>Saturday : <span class="fw-bold text-white">11am to 3pm</span></p>
						<p>Sunday : <span class="fw-bold text-white">Closed</span></p> -->
					</div>
				</div>
				<div class="col-md-9">
					<div class="contact_2l row">
						<div class="col-md-12">
							<h4>İletişime Geç</h4>
						</div>
					</div>
					<div class="contact_2l1 mt-3 row">
						<div class="col-md-6">
							<div class="contact_2l1i">
								<input class="form-control" placeholder="İsim*" type="text" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="contact_2l1i">
								<input class="form-control" placeholder="Email*" type="text" required>
							</div>
						</div>
						<div class="contact_2l1i mt-4">
							<textarea placeholder="Comment" class="form-control form_text" required></textarea>
							<h6 class="mt-3 mb-0"><a class="button" href="#"> Submit</a></h6>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	include "./views/_footer.php";
	?>

	<script>
		window.onscroll = function() {
			myFunction()
		};

		var navbar_sticky = document.getElementById("navbar_sticky");
		var sticky = navbar_sticky.offsetTop;
		var navbar_height = document.querySelector('.navbar').offsetHeight;

		function myFunction() {
			if (window.pageYOffset >= sticky + navbar_height) {
				navbar_sticky.classList.add("sticky")
				document.body.style.paddingTop = navbar_height + 'px';
			} else {
				navbar_sticky.classList.remove("sticky");
				document.body.style.paddingTop = '0'
			}
		}
	</script>

</body>

</html>