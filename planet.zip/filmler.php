<?php
$page_baslik = 'Filmler';
include "baglanti.php";
$sorgu = "SELECT * FROM `menuler`";
$sonuc = mysqli_query($conn, $sorgu);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Planet</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/global.css" rel="stylesheet">
	<link href="css/about.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Rajdhani&display=swap" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js"></script>

</head>

<body>
<section id="top">
    <div class="container">
      <div class="row top_1">
        <div class="col-md-3">
          <div class="top_1l pt-1">
            <h3 class="mb-0"><a class="text-white" href="./index.php"><i class="fa fa-video-camera col_red me-1"></i> Planet</a></h3>
          </div>
        </div>
        <div class="col-md-5">
          <div class="top_1m">
            <form action="./sorgusonuc.php" method="get">
            <div class="input-group">
              <input type="text" class="form-control bg-black" placeholder="Film Ara" name="sorgu">
              <span class="input-group-btn">
                <button class="btn btn text-white bg_red rounded-0 border-0" type="submit">
                  Araştır</button>
                </span>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-4">
          <div class="top_1r text-end">
            <ul class="social-network social-circle mb-0">
              <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-instagram"></i></a></li>
              <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
              <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="header">
    <nav class="navbar navbar-expand-md navbar-light" id="navbar_sticky">
      <div class="container">
        <a class="navbar-brand text-white fw-bold" href="index.php"><i class="fa fa-video-camera col_red me-1"></i> Planet</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mb-0">
            <?php while ($menu = $sonuc->fetch_assoc()) : ?>
              <li class="nav-item">
                <a class="nav-link <?php if ($menu["menu_baslik"] == "$page_baslik") : echo "active";
                                    endif ?> " aria-current="page" 
                                    href="
                                    <?php 
                                  if ($menu["menu_baslik"] == "Anasayfa") 
                                  {
                                    echo "index.php";
                                  } elseif($menu["menu_baslik"] == "İletişim") {
                                    echo "iletişim.php";
                                  }else{
                                    echo trim(strtolower($menu["menu_baslik"])) . '.php';
                                  } 
                                  ?>"><?php echo $menu["menu_baslik"] 
                                  ?>
                                  </a>
              </li>
            <?php endwhile ?>
          </ul>
        </div>
      </div>
    </nav>
  </section>

	<section id="center" class="center_o pt-2 pb-2">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Aksiyon</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Aksiyon</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `aksiyon`";
				$kategori='aksiyon';
				$sonuc2 = mysqli_query($conn, $sorgu2);
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Aksiyon</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4"><?php echo $film['görüntüleme'] ?> Görüntüleme</p>
								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>
							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<!-- Komedi -->
	<section id="center" class="center_o pt-2 pb-2" style="background-color: none;">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Komedi</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Komedi</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `komedi`";
				$sonuc2 = mysqli_query($conn, $sorgu2);
				$kategori='komedi';
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Komedi</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4">								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>


							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<!-- Drama -->
	<section id="center" class="center_o pt-2 pb-2" style="background-color: none;">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Drama</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Drama</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `drama`";
				$sonuc2 = mysqli_query($conn, $sorgu2);
				$kategori='drama';
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Drama</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4">								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>


							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<!-- Trajedi -->
	<section id="center" class="center_o pt-2 pb-2" style="background-color: none;">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Trajedi</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Trajedi</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `trajedi`";
				$sonuc2 = mysqli_query($conn, $sorgu2);
				$kategori='trajedi';
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Trajedi</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4">								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>


							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<!-- Romantizm -->
	<section id="center" class="center_o pt-2 pb-2" style="background-color: none;">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Romantizm</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Romantizm</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `romantizm`";
				$sonuc2 = mysqli_query($conn, $sorgu2);
				$kategori='romantizm';
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Romantizm</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4">								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>



							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<!-- Macera -->
	<section id="center" class="center_o pt-2 pb-2" style="background-color: none;">
		<div class="container-xl">
			<div class="row center_o1">
				<div class="col-md-5">
					<div class="center_o1l">
						<h2 class="mb-0">Macera</h2>
					</div>
				</div>
				<div class="col-md-7">
					<div class="center_o1r text-end">
						<h6 class="mb-0 col_red"><a href="index.php">Anasayfa</a> <span class="me-2 ms-2 text-light"><i class="fa fa-caret-right align-middle"></i></span> Macera</h6>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="team" class="pt-4 pb-4 bg_grey">
		<div class="container-xl">
			<div class="team_1i row">
				<?php
				$sorgu2 = "SELECT * FROM `macera`";
				$sonuc2 = mysqli_query($conn, $sorgu2);
				$kategori='macera';
				while ($film = $sonuc2->fetch_assoc()) :
				?>
					<div class="col-md-4 mt-2">
						<div class="team_1i1 clearfix position-relative">
							<div class="team_1i1i clearfix">
								<div class="grid clearfix">
									<figure class="effect-jazz mb-0">
										<a href="#"><img src="./images/<?php echo $film['resim'] ?>" class="w-100" alt="abc"></a>
									</figure>
								</div>
							</div>
							<div class="team_1i1i1 clearfix position-absolute w-100 bottom-0">
								<h4 class="col_red"><?php echo $film['baslik'] ?></h4>
								<h6>Macera</h6>
								<p><?php echo $film['açıklama'] ?></p>
								<span class="col_red">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</span>
								<p class="mb-0 mt-4">								<h6 class="mt-4"><a class="button" href="./film.php?kategori=<?php echo $kategori;?>&id=<?php  echo $film['id']; ?>">Anında İzle</a></h6>



							</div>
						</div>
					</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
	<?php include "./views/_footer.php"; ?>

	<script>
		window.onscroll = function() {
			myFunction()
		};

		var navbar_sticky = document.getElementById("navbar_sticky");
		var sticky = navbar_sticky.offsetTop;
		var navbar_height = document.querySelector('.navbar').offsetHeight;

		function myFunction() {
			if (window.pageYOffset >= sticky + navbar_height) {
				navbar_sticky.classList.add("sticky")
				document.body.style.paddingTop = navbar_height + 'px';
			} else {
				navbar_sticky.classList.remove("sticky");
				document.body.style.paddingTop = '0'
			}
		}
	</script>

</body>

</html>