-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 23 May 2024, 22:38:06
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `film`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin_info`
--

CREATE TABLE `admin_info` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pasword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `admin_info`
--

INSERT INTO `admin_info` (`id`, `username`, `pasword`) VALUES
(1, 'admin', 'adminumut'),
(2, 'admin', 'adminhüseyin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `aksiyon`
--

CREATE TABLE `aksiyon` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` text NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `aksiyon`
--

INSERT INTO `aksiyon` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(1, 'Deneme', 'hasdfuyfwe fdywef dy uf weytfdewytdfwety fdy twegf deneme ytdefytewfdytwe ftywefytdewf ytdwety', '5631705.jpg', '<iframe height=\"450\" class=\"w-100\" src=\"https://www.youtube.com/embed/1_mv8ltHwb8?si=U5h-oyIss3_xd3Ls\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 2000),
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '<iframe height=\"450\" class=\"w-100\" src=\"https://www.youtube.com/embed/ZSozwZvpaNs?si=fZP2gLJ1hp7yInFt\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe deneme', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `drama`
--

CREATE TABLE `drama` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` varchar(1000) NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `drama`
--

INSERT INTO `drama` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(1, 'Deneme', 'hasdfuyfwe fdywef dy uf weytfdewytdfwety fdy twegf ytdefytewfdytwe ftywefytdewf ytdwety', '5631705.jpg', 'xd', 2000),
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `editörsectikleri`
--

CREATE TABLE `editörsectikleri` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `kategori` varchar(1000) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `görüntüleme` int(100) NOT NULL,
  `youtubeiafarme` text NOT NULL,
  `açıklama` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `editörsectikleri`
--

INSERT INTO `editörsectikleri` (`id`, `baslik`, `kategori`, `resim`, `görüntüleme`, `youtubeiafarme`, `açıklama`) VALUES
(1, 'Hayaller', 'Aksiyon', 'ressim.jpg', 10, '', ''),
(2, 'Deneme', 'Aksiyon', 'ressim.jpg', 1000, '', ''),
(3, 'Deneme2', 'Romantizm', 'ressim.jpg', 3000, '', ''),
(4, 'Deneme 3', 'trajedi', 'ressim.jpg', 50000, '', ''),
(13, 'Deneme', 'Aksiyon', 'akbank-hata-2.png', 12345, '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `komedi`
--

CREATE TABLE `komedi` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` varchar(1000) NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `komedi`
--

INSERT INTO `komedi` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(1, 'Deneme', 'hasdfuyfwe fdywef dy uf weytfdewytdfwety fdy twegf ytdefytewfdytwe ftywefytdewf ytdwety', '5631705.jpg', '', 2000),
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `macera`
--

CREATE TABLE `macera` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` varchar(1000) NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `macera`
--

INSERT INTO `macera` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `menuler`
--

CREATE TABLE `menuler` (
  `id` int(11) NOT NULL,
  `menu_baslik` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `menuler`
--

INSERT INTO `menuler` (`id`, `menu_baslik`) VALUES
(1, 'Anasayfa'),
(2, 'Filmler'),
(3, 'Hakkımızda'),
(4, 'İletişim');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `romantizm`
--

CREATE TABLE `romantizm` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` varchar(1000) NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `romantizm`
--

INSERT INTO `romantizm` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(1, 'Deneme', 'hasdfuyfwe fdywef dy uf weytfdewytdfwety fdy twegf ytdefytewfdytwe ftywefytdewf ytdwety', '5631705.jpg', '', 2000),
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider_films`
--

CREATE TABLE `slider_films` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(1000) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `imdb` varchar(100) NOT NULL,
  `oyunclar` varchar(100) NOT NULL,
  `turler` varchar(100) NOT NULL,
  `sure` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `yıl` int(10) NOT NULL,
  `youtubeifarme` text NOT NULL,
  `aktif` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `slider_films`
--

INSERT INTO `slider_films` (`id`, `baslik`, `açıklama`, `kategori`, `imdb`, `oyunclar`, `turler`, `sure`, `resim`, `yıl`, `youtubeifarme`, `aktif`) VALUES
(1, 'Ölümlü Dünya 2', 'Mermer ailesinin her bir ferdi, kendi kişisel sorunlarıyla mücadele ediyor. Bu, izleyici olarak bizi her bir karaktere, ayrı bir bakış açısıyla yaklaşmamızı sağlıyor. Her bir karakterin yaşadığı sorunlar, izleyiciyi kendi iç dünyalarına doğru bir yolculuğa çıkarıyor. Serhan özellikle eşi Begüm\'ün yeni yaşam tarzına uyum sağlama konusunda zorluklar yaşıyor.', 'Aksiyon', '7.2', 'Ahmet Mümtaz Taylan, Alper Kul, Doğu Demirkol, Feyyaz Yiğit, Giray Altınok', 'Aksiyon,Komedi,Suç', '1s 20dk', 'maxresdefault.jpg', 2023, 'dw', 1),
(3, 'Malefiz', 'Maleficent,” 1959 klasiği “Uyuyan Güzel”in en ikonik kötü karakterinin anatılmamış hikâyesinde, Maleficent’ın kalbini taşlaştıran ve onun, bebek Aurora’yı lanetlemesine yol açan olaylar anlatılıyor', 'Aksiyon', '6.9', 'Angelina Jolie , Elle Fanning , Sharlto Copley , Sam Riley , Juno Temple , Imelda Staunton , Lesley ', 'Romantik, Aile, Macera, Fantastik, Aksiyon', '1s 35dk', '531615.jpg', 2014, '', 0),
(4, 'Malefiz', 'Maleficent,” 1959 klasiği “Uyuyan Güzel”in en ikonik kötü karakterinin anatılmamış hikâyesinde, Maleficent’ın kalbini taşlaştıran ve onun, bebek Aurora’yı lanetlemesine yol açan olaylar anlatılıyor', 'Aksiyon', '6.9', 'Angelina Jolie , Elle Fanning , Sharlto Copley , Sam Riley , Juno Temple , Imelda Staunton , Lesley ', 'Romantik, Aile, Macera, Fantastik, Aksiyon', '1s 35dk', '531615.jpg', 2014, '', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `soneklenenler`
--

CREATE TABLE `soneklenenler` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `yıldız` int(100) NOT NULL,
  `görüntüleme` int(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `soneklenenler`
--

INSERT INTO `soneklenenler` (`id`, `baslik`, `açıklama`, `kategori`, `yıldız`, `görüntüleme`, `resim`, `youtubeiafarme`) VALUES
(1, 'Hayalimdeki Düğün', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Aksiyon', 3, 2, '5631705.jpg', ''),
(3, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Komedi', 0, 50, '5631705.jpg', ''),
(4, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Drama', 0, 50, '5631705.jpg', ''),
(5, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Trajedi', 0, 50, '5631705.jpg', ''),
(6, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(7, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(8, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(9, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(10, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(11, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', ''),
(12, 'deneme', 'Bu filmin merkezinde, sevdiklerini tehlikeli bir durumdan kurtarmakla görevli, yakında evlenecek', 'Romantizm', 0, 50, '5631705.jpg', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `trajedi`
--

CREATE TABLE `trajedi` (
  `id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `açıklama` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `youtubeiafarme` varchar(1000) NOT NULL,
  `görüntüleme` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `trajedi`
--

INSERT INTO `trajedi` (`id`, `baslik`, `açıklama`, `resim`, `youtubeiafarme`, `görüntüleme`) VALUES
(1, 'Deneme', 'hasdfuyfwe fdywef dy uf weytfdewytdfwety fdy twegf ytdefytewfdytwe ftywefytdewf ytdwety', '5631705.jpg', '', 2000),
(2, 'efwwwwwwwwwwwwwwwwww', 'weffffffffff', '5631705.jpg', '', 100000),
(3, 'efwwwwwewfew', 'wefewfewwe', '5631705.jpg', '', 500000000),
(4, 'fewfewfwe', 'weffffffffff e fffffffffffffff \n ffffffwww wwwwwwwwwwwwwwwwdcv \n feferfregfuyrg rr er  reyftreyfbery', '5631705.jpg', '', 55454),
(5, 'wefwwefew', 'fıe geıuweeeeeee eeeeeeeeeeeeeeeeeeeeeeeeefew fıheawıfyhwed uyıfu', '5631705.jpg', '', 5000),
(6, 'fewafwef', 'dfewfewefsdsuyg 87etwey f78ewgfyew gfy ewgyf eeywf eyw gfuywe g8fye ew8 \r\n', '5631705.jpg', '', 2000);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `aksiyon`
--
ALTER TABLE `aksiyon`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `drama`
--
ALTER TABLE `drama`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `editörsectikleri`
--
ALTER TABLE `editörsectikleri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `komedi`
--
ALTER TABLE `komedi`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `macera`
--
ALTER TABLE `macera`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `menuler`
--
ALTER TABLE `menuler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `romantizm`
--
ALTER TABLE `romantizm`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `slider_films`
--
ALTER TABLE `slider_films`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `soneklenenler`
--
ALTER TABLE `soneklenenler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `trajedi`
--
ALTER TABLE `trajedi`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `aksiyon`
--
ALTER TABLE `aksiyon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Tablo için AUTO_INCREMENT değeri `drama`
--
ALTER TABLE `drama`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `editörsectikleri`
--
ALTER TABLE `editörsectikleri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Tablo için AUTO_INCREMENT değeri `komedi`
--
ALTER TABLE `komedi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `macera`
--
ALTER TABLE `macera`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `menuler`
--
ALTER TABLE `menuler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `romantizm`
--
ALTER TABLE `romantizm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `slider_films`
--
ALTER TABLE `slider_films`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `soneklenenler`
--
ALTER TABLE `soneklenenler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `trajedi`
--
ALTER TABLE `trajedi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
