
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<title>Admin Console</title>
	<!-- Bootstrap core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/nav.css" rel="stylesheet">
	<link href="css/global.css" rel="stylesheet">
	<link href="css/authentication.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">


</head>

<body>

	<section id="autcard_log">
		<div class="container">
			<div class="row">
				<div class="card">
					<div class="card-body p-0">
						<div class="autcard_logi row">
							<div class="col-md-5 p-0">
								<div class="autcard_logil text-center" style="background:#3587f4; padding:40px 30px;">
									<h2 style="font-size: 1.728rem;" class="text-center mb-4"><a class="text-white" href="#">Admin Panel</a></h2>
									<p class="opacity-75 text-white">Hüseyinmisin Umut mu ? <br> Panel Film Site</p>
									<h6 class="text-light" style="margin-top:120px;"> <br> Önemseme Buraları <br> Don't have an account?<br>
										<a class="text-light" href="#">Get started!</a>
									</h6>
									<p style="margin-top:50px;" class="opacity-75 text-white bold text_13 mb-0">Read our
										<a class="opacity-75 text-white" href="#">terms</a> and <a class="opacity-75 text-white" href="#">conditions</a>
									</p>
								</div>
							</div>
							<div class="col-md-7">
								<div class="autcard_logir" style="padding:40px 30px;">
									<h3 style="font-size: 1.728rem;" class="mb-3">Admin Login</h3>
									<form action="./loginkontrol.php" method="post">
										<h6 class="colo_8 mb-2 font_14">Kullanıcı Adı</h6>
										<input class="form-control form_log" type="text" name="username">
										<h6 class="colo_8 mb-2 font_14 mt-3">Şifre</h6>
										<input class="form-control form_log" type="password" name="password">
										<div class="d-flex justify-content-between mt-3">
											<div class="form-check">
												<input class="form-check-input" type="checkbox" value="" checked="checked" id="remember">
												<label class="form-check-label" for="remember">
													<span class="bold colo_8 font_14">Remember Me</span>
												</label>
											</div>
											<a href="#" class="colo_4 text_13">Forgot Password?</a>
										</div>
										<button class="btn btn-primary d-block w-100 mt-3 bold" type="submit" name="submit">Log in</button>
										</form>
										<?php if($_GET):?>
										<h6 style="color: red;" class="mt-2"><?php if($_GET['onay'] && $_GET['onay']=="false"){
											echo "Kullanıcı adı veya şifre hatalı";
										} endif;?></h6>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<script src="js/bootstrap.bundle.min.js"></script>

	</script>
	<script src="js/global.js"></script>


</body>

</html>