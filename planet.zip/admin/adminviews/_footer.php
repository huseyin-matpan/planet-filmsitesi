				<div class="row footer mt-4">
					<div class="col-md-8">
						<div class="footer_1l">
							<p class="mb-0 col_3">© 2024 Filmizle. All Rights Reserved | Design by <a class="col_1 font-weight-bold" href="https://inovasyonsoftware.com.tr">İnoavasyon Software</a></p>
						</div>
					</div>
				</div>
				</main>
				</div>
				</div>

				<script src="js/bootstrap.bundle.min.js"></script>
				<script src="js/global.js"></script>

				</body>

				</html>