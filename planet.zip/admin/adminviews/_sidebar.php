<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Admin Console</title>
    Bootstrap core CSS
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/nav.css" rel="stylesheet">
    <link href="css/global.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="js/codebase/dhtmlxcalendar.css" />
    <script src="js/codebase/dhtmlxcalendar.js"></script>
    <script src="js/chart.min.js"></script>
    <link href="css/table.css" rel="stylesheet">

</head>

<body>

    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap mt-0 p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="index.php">
            <h4>ADMİN</h4>
        </a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <ul class="nav hide">
            </li>
            <li class="nav-item sign_box dropdown">
                <a class="nav-link dropdown-toggle text-white  border-0" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img alt="Logo" class="rounded-circle" width="30" height="30" src="./img/profile.jpg"> Hoşgeldin<span class="ms-2 text text-warning">Admin</span> </a>
            </li>
        </ul>

    </header>



    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse" style="overflow-y: auto; max-height:inherit;">
                <div class="position-sticky">

                    <ul class="nav flex-column mb-2 list-unstyled ps-0">
                        <li class="nav-item">
                            <a href="index.php" class="btn btn-toggle align-items-center rounded w-100 tag_m  no_drop active_tab"><i class="fa fa-home icon-before"></i><span class="btn">Anasayfa</span></a>

                        </li>

                        <li class="nav-item">

                            <a href="javascript:void(0);" class="btn btn-toggle align-items-center rounded collapsed  w-100 tag_m" data-bs-toggle="collapse" data-bs-target="#orders-collapse" aria-expanded="false">
                                <!-- <i class="fa-solid fa-list-check"></i> -->
                                <i class="fa fa-shopping-cart icon-before"></i><span class="btn">Site Ayarları</span><i class="fa fa-chevron-right"></i></a>
                            <div class="collapse" id="orders-collapse">
                                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                                    <li><a href="ecommerce_prod.html" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Site Başlık</span></a></li>
                                    <li><a href="ecommerce_prod_details.html" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Seo Ayarları</span></a></li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">

                            <a href="javascript:void(0);" class="btn btn-toggle align-items-center rounded collapsed w-100 tag_m" data-bs-toggle="collapse" data-bs-target="#account-collapse" aria-expanded="false"><i class="fa fa-briefcase icon-before"></i><span class="btn">Kategoriler</span><i class="fa fa-chevron-right"></i></a>
                            <div class="collapse" id="account-collapse">
                                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                                    <li><a href="./kategorigöster2.php?kategori=slider_films" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Slider Filimleri</span></a></li>
                                    <li><a href="./kategorigöster2.php?kategori=soneklenenler" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Son Eklenenler</span></a></li>
                                    <li><a href="./kategorigöster2.php?kategori=editörsectikleri	" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Editör Seçtikleri</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=aksiyon" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Aksiyon</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=drama" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Drama</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=komedi" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Komedi</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=macera" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Macera</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=romantizm" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Romantizm</span></a></li>
                                    <li><a href="./kategorigöster.php?kategori=trajedi" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Trajedi</span></a></li>

                                </ul>
                            </div>
                        </li>



                        <li class="nav-item">

                            <a href="javascript:void(0);" class="btn btn-toggle align-items-center rounded collapsed w-100 tag_m" data-bs-toggle="collapse" data-bs-target="#Authent-collapse" aria-expanded="false"><i class="fa fa-lock icon-before"></i><span class="btn">Film Ekle</span><i class="fa fa-chevron-right"></i></a>
                            <div class="collapse" id="Authent-collapse">
                            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                                    <li><a href="./filmekle.php?kategori=slider_films" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Slider Filim ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=soneklenenler" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Son Eklenenler ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=editörsectikleri	" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Editör Seçtikleri ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=aksiyon" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Aksiyon film ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=drama" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Drama film ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=komedi" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Komedi film ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=macera" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Macera film ekle</span></a></li>
                                    <li><a href="./filmekle.php?kategori=romantizm" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Romantizm film ekle </span></a></li>
                                    <li><a href="./filmekle.php?kategori=trajedi" class="link-dark rounded w-100"><span><i style="font-size:8px; vertical-align:middle; margin-right:10px;" class="fa fa-circle-o"></i> Trajedi film ekle</span></a></li>

                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a href="email.html" class="btn btn-toggle align-items-center rounded w-100 tag_m  no_drop"><i class="fa fa-envelope icon-before"></i><span class="btn">Email</span></a>
                        </li>
                    </ul>
                </div>
            </nav>