<?php
$host = 'localhost';
$dbname = 'film';
$user = 'root';
$password = '';

$conn = new mysqli($host, $user, $password, $dbname);
$conn->set_charset("utf8");
$username = $_POST['username'];
$password = $_POST['password'];
$sorgu = "SELECT * FROM `admin_info`";
$result = mysqli_query($conn, $sorgu);
$onay='false';
    while ($row = $result->fetch_assoc()) {
        if ($row["username"] == $username && $row["pasword"] == $password) {
            header("Location: index.php");
            session_start();
            $_SESSION["username"] = $row["username"];
            die;
            $onay=true;
        }
    }
    header("Location: login.php?onay={$onay}");

