<?php
require "./adminviews/_sidebar.php";
require "../baglanti.php";
if (isset($_GET['kategori'])) {
    $gelenkategori = $_GET['kategori'];
    $tableName = ucfirst(strtolower($gelenkategori));
    $sorgu = "SELECT * FROM $tableName";
    $sonuc = mysqli_query($conn, $sorgu);
?>
    <main class="col-md-9 ms-sm-auto common col-lg-10 px-md-4">
        <table class="table table-striped table-centered mb-0">
            <thead>
                <tr>
                    <th>Başlık</th>
                    <th>Açıklama</th>
                    <th>Resim</th>
                    <th>Youtube İfarme</th>
                    <th>Görüntüleme</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $sonuc->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['baslik'] ?></td>
                        <td><?php echo $row['açıklama'] ?></td>
                        <td>
                            <img src="../images/<?php echo $row['resim'] ?>" class="w-100" width="100" height="100" alt="abc">
                        </td>
                        <td>
                            <p><?php echo htmlspecialchars($row['youtubeiafarme']) ?></p>
                        </td>
                        <td>
                            <p><?php echo $row['görüntüleme'] ?></p>
                        </td>
                        <td>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="Edit" class="d-inline-block mb-0"><a href="#"><i style="vertical-align:middle; margin-right:5px;" class="fa fa-edit col_3"></i></a></h6>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Delete" class="d-inline-block mb-0"><a href="#"><i class="fa fa-trash col_3"></i></a></h6>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php
} else {
    echo "hata";
    header("location: index.php");
}
    ?>


















    <?php
    include "./adminviews/_footer.php";
    ?>