<?php
require "./adminviews/_sidebar.php";
require "../baglanti.php";
if (isset($_GET['kategori'])) {
    $gelenkategori = $_GET['kategori'];
    if ($gelenkategori == "soneklenenler") {
        $sorgu = "SELECT * FROM soneklenenler";
    } elseif ($gelenkategori == "slider_films") {
        $sorgu = "SELECT * FROM slider_films";
    }elseif ($gelenkategori == "editörsectikleri") {
        $sorgu = "SELECT * FROM editörsectikleri";
    }
    $sonuc = $conn->query($sorgu);
?>
    <main class="col-md-9 ms-sm-auto common col-lg-10 px-md-4">
        <table class="table table-striped table-centered mb-0">
            <thead>
                <?php
                if ($gelenkategori == "soneklenenler") {
                ?>
                    <tr>
                        <th>Başlık</th>
                        <th>Açıklama</th>
                        <th>Kategori</th>
                        <th>Görüntüleme</th>
                        <th>Youtube İfarme</th>
                        <th>Resim</th>
                        <th>İşlemler</th>
                    </tr>
            </thead>
            <tbody>
                <?php while ($row = $sonuc->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['baslik'] ?></td>
                        <td><?php echo $row['açıklama'] ?></td>
                        <td>
                            <?php echo $row['kategori'] ?>
                        </td>
                        <td>
                            <p><?php echo $row['görüntüleme'] ?></p>
                        </td>
                        <td>
                            <p><?php echo $row['youtubeifarme'] ?></p>
                        </td>
                        <td>
                            <img src="../images/<?php echo $row['resim'] ?>" alt="resim" width="100" height="100">
                        </td>
                        <td>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="Edit" class="d-inline-block mb-0"><a href="#"><i style="vertical-align:middle; margin-right:5px;" class="fa fa-edit col_3"></i></a></h6>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Delete" class="d-inline-block mb-0"><a href="#"><i class="fa fa-trash col_3"></i></a></h6>
                        </td>
                    </tr>
            <?php }
                } ?>
            <?php
            if ($gelenkategori == "slider_films") {
            ?>
                <tr>
                    <th>Başlık</th>
                    <th>Açıklama</th>
                    <th>Kategori</th>
                    <th>Imdb</th>
                    <th>Oyuncular</th>
                    <th>Türler</th>
                    <th>Süre</th>
                    <th>Yıl</th>
                    <th>Youtube İfarme</th>
                    <th>Resim</th>
                    <th>İşlemler</th>
                </tr>
                </thead>
            <tbody>
                <?php while ($row = $sonuc->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['baslik'] ?></td>
                        <td><?php echo $row['açıklama'] ?></td>
                        <td>
                            <?php echo $row['kategori'] ?>
                        </td>
                        <td>
                            <p><?php echo $row['imdb'] ?></p>
                        </td>
                        <td>
                            <?php echo $row['oyunclar'] ?>
                        </td>
                        <td>
                            <?php echo $row['turler'] ?>
                        </td>
                        <td>
                            <?php echo $row['sure'] ?>
                        </td>
                        <td>
                            <?php echo $row['yıl'] ?>
                        </td>
                        <td>
                            <?php echo $row['youtubeifarme'] ?>
                        </td>
                        <td>
                           <img src="../images/<?php echo $row['resim'] ?>" alt="resim" width="100" height="100">
                        </td>
                        <td>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="Edit" class="d-inline-block mb-0"><a href="#"><i style="vertical-align:middle; margin-right:5px;" class="fa fa-edit col_3"></i></a></h6>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Delete" class="d-inline-block mb-0"><a href="#"><i class="fa fa-trash col_3"></i></a></h6>
                        </td>
                    </tr>
            <?php }
            } ?>
             <?php
                if ($gelenkategori == "editörsectikleri") {
                ?>
                    <tr>
                        <th>Başlık</th>
                        <th>Açıklama</th>
                        <th>Kategori</th>
                        <th>Görüntüleme</th>
                        <th>Youtube İfarme</th>
                        <th>Resim</th>
                        <th>İşlemler</th>
                    </tr>
            </thead>
            <tbody>
                <?php while ($row = $sonuc->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['baslik'] ?></td>
                        <td><?php echo $row['açıklama'] ?></td>
                        <td>
                            <?php echo $row['kategori'] ?>
                        </td>
                        <td>
                            <p><?php echo $row['görüntüleme'] ?></p>
                        </td>
                        <td>
                            <p><?php echo $row['youtubeifarme'] ?></p>
                        </td>
                        <td>
                            <img src="../images/<?php echo $row['resim'] ?>" alt="resim" width="100" height="100">
                        </td>
                        <td>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="Edit" class="d-inline-block mb-0"><a href="#"><i style="vertical-align:middle; margin-right:5px;" class="fa fa-edit col_3"></i></a></h6>
                            <h6 data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Delete" class="d-inline-block mb-0"><a href="#"><i class="fa fa-trash col_3"></i></a></h6>
                        </td>
                    </tr>
            <?php }
                } ?>
            </tbody>
        </table>
    <?php
} else {
    echo "hata";
    header("location: index.php");
}
    ?>

    <?php
    include "./adminviews/_footer.php";
    ?>