<?php
session_start();
if (isset($_SESSION["username"])) {
	require "../baglanti.php";
	include "./adminviews/_sidebar.php";
	$sorgu = "SELECT * FROM `aksiyon`";
	$toplamfilm = 0;
	$toplam = mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `drama`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `komedi`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `macera`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `romantizm`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `trajedi`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `editörsectikleri`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `slider_films`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
	$sorgu = "SELECT * FROM `soneklenenler`";
	$toplam += mysqli_query($conn, $sorgu)->num_rows;
?>
	<main class="col-md-9 ms-sm-auto common col-lg-10 px-md-4">
		<div class="row analytic_1">
			<div class="col-md-3">
				<div class="analytic_1l">
					<h5 class="mb-0">İstatistikler</h5>
				</div>
			</div>
		</div>
		<div class="row analytic_2 mt-4">
			<div class="col-xl-3 col-md-5 col-lg-5">
				<div class="analytic_2l">
					<div class="analytic_2l1 bg-white">
						<h6 class="font_14">Toplam Kategori Sayısı </h6>
						<h3>9 <span class="pull-right col_3"><i class="fa fa-users"></i></span></h3>
						<p class="col_2 mb-0"></p>
					</div>
					<div class="analytic_2l1 bg-white mt-4">
						<h6 class="font_14">Toplam Film</h6>
						<h3><?php echo $toplam; ?> <span class="pull-right col_3"><i class="fa fa-file"></i></span></h3>
						<p class="col_4 mb-0"></p>
					</div>

				</div>
			</div>
		</div>
		<div class="row Ecommerce_1 mt-4">
			<div class="col-lg-12 col-md-6">
				<div class="Ecommerce_1l row">
					<div class="col-md-6">
						<div class="analytic_2l1 bg-white">
							<h6 class="font_14">Kayıtlı Mail Adresi </h6>
							<h3>36,254 </h3>
						</div>
					</div>
					<div class="col-md-6">
						<div class="analytic_2l1 bg-white">
							<h6 class="font_14">Boş </h6>
							<h3>36,254 </h3>
						</div>
					</div>
				</div>
				<div class="Ecommerce_1l mt-4 row">
					<div class="col-md-6">
						<div class="analytic_2l1 bg-white">
							<h6 class="font_14">Boş </h6>
							<h3>$6,254 </h3>
						</div>
					</div>
					<div class="col-md-6">
						<div class="analytic_2l1 bg-white">
							<h6 class="font_14">Boş </h6>
							<h3>+ 30.56% </h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php
	require "./adminviews/_footer.php";
} else {
	header("location:login.php");
}
	?>