<?php
$host = 'localhost';
$dbname = 'film';
$user = 'root';
$password = '';

$conn = new mysqli($host, $user, $password, $dbname);
$conn->set_charset("utf8");
$query = "SELECT * FROM `slider_films`";
$result = mysqli_query($conn,$query);
?>
<section id="center" class="center_home">
 <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2" class="" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner ">
	<?php while($film = $result->fetch_assoc()): ?>
    <div class="carousel-item <?php if($film['aktif']==1): echo 'active'; endif; ?>">
      <img src="../images/<?php echo $film['resim'] ?>" class="d-block w-100" alt="...">
      <div class="carousel-caption d-md-block">
       <h1 class="font_60"><?php echo $film['baslik'] ?></h1>
	   <h6 class="mt-3">
	    <span class="col_red me-3">
		 <i class="fa fa-star"></i>
		 <i class="fa fa-star"></i>
		 <i class="fa fa-star"></i>
		 <i class="fa fa-star"></i>
		 <i class="fa fa-star-half-o"></i>
		</span>
		<?php echo $film['sure'] ?> (Imdb)      Yapım Yılı : <?php echo $film['yıl'] ?>
		 <a class="bg_red p-2 pe-4 ps-4 ms-3 text-white d-inline-block" href="../filimler.php"><?php echo $film['kategori'] ?></a>
	   </h6>
	   <p class="mt-3"><?php echo $film['açıklama'] ?></p>
	   <p class="mb-2"><span class="col_red me-1 fw-bold">Oyuncular:</span><?php echo $film['oyunclar'] ?></p>
	   <p class="mb-2"><span class="col_red me-1 fw-bold">Türler:</span> <?php echo $film['turler'] ?></p>
	   <p><span class="col_red me-1 fw-bold">Süre::</span><?php echo $film['sure'] ?> </p>	
	   <h6 class="mt-4"><a class="button" href="./film.php?kategori=slider_films&id=<?php  echo $film['id']; ?>"><i class="fa fa-play-circle align-middle me-1"></i>Filmi İzle </a></h6>
      </div>
    </div>
	<?php endwhile; ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>