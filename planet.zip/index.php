<?php 
$page_baslik = 'Anasayfa';
require "./views/_navbar.php";
require "./views/_slider.php";
require "./views/_soneklenenler.php";
require "./views/_editorsectikleri.php";
require "./views/_footer.php";
?>

