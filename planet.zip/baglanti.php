<?php
$host = 'localhost';
$dbname = 'film';
$user = 'root';
$password = '';

$conn = new mysqli($host, $user, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
